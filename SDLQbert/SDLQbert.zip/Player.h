#pragma once
#include "AnimatedTexture.h"
#include "InputManager.h"
#include"AudioManager.h"


class Player : public GameEntity
{

private:

	Timer * mTimer;
	InputManager * mInput;
	AudioManager *mAudio;

	bool mVisible;
	bool mAnimating;

	int mbounce;
	int mScore;
	int mLives;

	bool mState;

	bool flags[4];

	float MoveSpeed;
	Vector2 MinMoveBounds;
	Vector2 MaxMoveBounds;

	Texture * mDeath;
	AnimatedTexture * mJumpAnimationA;
	AnimatedTexture * mJumpAnimationD;
	AnimatedTexture * mJumpAnimationQ;
	AnimatedTexture * mJumpAnimationE;

	Texture * mQbert;

private:

	void HandleMovement();

public:

	Player();
	~Player();

	void Visible(bool visible);

	bool IsAnimating();

	bool  GetFlagsStatus(char ch);

	int Score();
	int Lives();

	void AddScore(int change);

	void WasHit();

	int Bounce();
	
	void CubeLanded();


	void Update();

	void Render();

};