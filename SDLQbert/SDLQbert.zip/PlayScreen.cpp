#include"PlayScreen.h"

PlayScreen::PlayScreen()
{
	mTimer = Timer::Instance();

	mInput = InputManager::Instance();
	
	mRightSideBar = new PlaySideBar();
	mLeftSidebar = new PlayerSideBar();
	mStartLabel = new Texture("START","Q-bert Original.ttf", 20, { 230,230,230 });
	mStartLabel->Parent(this);
	mStartLabel->Pos(Vector2(Graphics::Instance()->SCREEN_WIDTH * 0.5f, Graphics::Instance()->SCREEN_HEIGHT * 0.5f));

	mEndLabel = new Texture("GAME OVER", "Q-bert Original.ttf", 40, { 230,230,230 });
	mEndLabel->Parent(this);
	mEndLabel->Pos(Vector2(Graphics::Instance()->SCREEN_WIDTH * 0.5f, Graphics::Instance()->SCREEN_HEIGHT * 0.5f));


	mLevel = NULL;

	mRightSideBar->Parent(this);
	mLeftSidebar->Parent(this);

	mLevelStartDelay = 1.0f;
	mLevelStarted = false;

	mLeftSidebar->SetMiniCube(mCurrentRound);
	mPlayer = NULL;
	
}

PlayScreen::~PlayScreen()
{

	delete mRightSideBar;
	mRightSideBar = NULL;

	delete mLeftSidebar;
	mLeftSidebar = NULL;

	mTimer = NULL;
	mInput = NULL;

	delete mStartLabel;
	mStartLabel = NULL;

	delete mLevel;
	mLevel = NULL;

	delete mPlayer;
	mPlayer = NULL;

	delete mEndLabel;
	mEndLabel = NULL;
}

void PlayScreen::StartFirstLevel()
{
	mCurrentRound++;
	if (mCurrentRound > 3)
	{
		mCurrentRound = mCurrentRound % 3;
		mCurrentLevel++;
		if (mCurrentLevel > 2)
		{
			StartNewGame();
		}
	}
	mLevelStarted = true;
	mLevelStartTimer = 0.0f;
	delete mLevel;
	mPlayer->Pos(Vector2(360, 170));
	mLevel = new Level(mCurrentLevel, mCurrentRound, mRightSideBar, mPlayer);
}

void PlayScreen::StartNextLevel()
{
	mCurrentRound++;
	if (mCurrentRound > 3)
	{
		mCurrentRound = mCurrentRound % 3;
		mCurrentLevel++;
		if (mCurrentLevel > 2)
		{
			StartNewGame();
		}
	}
	mLevelStarted = true;
	mLevelStartTimer = 0.0f;
	mPlayer->Pos(Vector2(360, 170));
	mLevel->Reset(mCurrentLevel, mCurrentRound);
}


void PlayScreen::StartNewGame()
{
	delete mPlayer;
	mPlayer = new Player();
	mPlayer->Pos(Vector2(360,170));
	mPlayer->Active(false);

	mLeftSidebar->SetPlayerLives(mPlayer->Lives());
	mLeftSidebar->SetPlayerScore(mPlayer->Score());
	mRightSideBar->SetHighScore(10000);
	mGameStarted = false;
	mCurrentLevel = 1;
	mCurrentRound = 0;
	mRightSideBar->SetLevel(mCurrentLevel, mCurrentRound);

}


void PlayScreen::Update()
{
	if (mGameStarted)
	{
		if (!mLevelStarted)
		{
			mLevelStartTimer += mTimer->DeltaTime();
			if (mLevelStartTimer >= mLevelStartDelay )
			{
				StartFirstLevel();
			}

			

			if (mPlayer->Lives() == 0)
			{
				mGameOver = true;
			}
		}

	}
	else
	{
		SDL_Delay(1000);
		mGameStarted = true;
	}

	if (mGameStarted && mLevelStarted)
	{
		mRightSideBar->Update();
		mLeftSidebar->Update();
		mPlayer->Update();
		mLeftSidebar->SetPlayerScore(mPlayer->Score());
		mLeftSidebar->SetPlayerLives(mPlayer->Lives());
		mLevel->Update();
		if (mPlayer->Lives() < 1)
		{
			mGameOver = true;
		}
		if (mPlayer->Bounce() == MAX_BOUNCES)
		{
			StartNextLevel();
		}
		if (mInput->KeyPressed(SDL_SCANCODE_N))
		{
			StartNextLevel();
		}
	
	}

}

void PlayScreen::Render()
{
	

	if (!mGameStarted)
	{
		mStartLabel->Render();
	}

	if (mGameStarted && mLevelStarted)
	{
		mLevel->Render();

		mLeftSidebar->Render();
	}

	if (mGameOver)
	{
		mEndLabel->Render();
	}
}