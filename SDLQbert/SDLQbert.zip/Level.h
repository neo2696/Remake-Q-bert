#pragma once
#include"InputManager.h"
#include "AnimatedTexture.h"
#include "PlaySideBar.h"
#include"Player.h"
#include"Cube.h"

class Level : public GameEntity
{
private:

	Timer * mTimer;
	PlaySideBar *RightSideBar;

	int mRound;
	int mLevel;
	bool mLevelStarted;

	float mLabelTimer;

	Texture *mLevelLabel;
	ScoreBoard *mLevelNumber;

	float mLevelOnScreen;
	float mLevelOffScreen;

	Texture *mRoundLabel;
	ScoreBoard *mRoundNumber;

	//Player

	Player * mPlayer;
	//Level Entities
	Cube * mCube[7][7];

	Texture * mDisk1;
	Texture *mDisk2;


private:

	void StartRound();

	void Collision(Player * player , Cube * box);

	

public:

	Level(int level, int round,PlaySideBar * sidebar, Player* player);
	~Level();

	void Reset(int level,int round);

	void Update();

	void Render();
	 
};