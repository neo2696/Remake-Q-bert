#include"Cube.h"

Cube::Cube()
{
	//Default State texture 0 Bounce
	mCubeTexture[0][0]= new Texture("cube1.png");
	mCubeTexture[0][1] = new Texture("cube12.png");
	mCubeTexture[0][2] = new Texture("cube13.png");

	//Texture at one bounce
	mCubeTexture[1][0] = new Texture("cube2.png");
	mCubeTexture[1][1] = new Texture("cube21.png");
	mCubeTexture[1][2] = new Texture("cube22.png");

	//Texture at 2 bounce
	mCubeTexture[2][0] = new Texture("cube3.png");
	mCubeTexture[2][1] = new Texture("cube31.png");
	mCubeTexture[2][2] = new Texture("cube32.png");


	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			mCubeTexture[i][j]->Parent(this);
		}
	}

}

Cube ::~Cube()
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			delete  mCubeTexture[i][j];
			mCubeTexture[i][j] = NULL;
		}
	}
}

void Cube::SetMAXBounce(int bounce)
{
	CurBounce = 0;
	MaxBounce = bounce;
	
}

void Cube::GetRound(int round)
{
	mRound = round;
}

void Cube::Hit()
{
	CurBounce = (CurBounce + 1) % MaxBounce+1;
}

int Cube::GetBounce()
{
	return CurBounce;
}

void Cube::Update()
{
	
}

void Cube::Render()
{
	mCubeTexture[mRound-1][CurBounce]->Render();
}