#include"Level.h"
int XPOS = 0;
int YPOS = 0;
Level::Level(int level, int round,PlaySideBar * sidebar,Player * player)
{
	mTimer = Timer::Instance();
	RightSideBar = sidebar;
	RightSideBar->SetLevel(level, round);

	
	mLevel = level;
	mRound = round;
	mLevelStarted = false;

	mLabelTimer = 0.0f;

	mLevelLabel = new Texture("Level ", "Q-Bert Original.ttf", 24, { 230,230,230 });
	mLevelLabel->Parent(this);
	mLevelLabel->Pos(Vector2(Graphics::Instance()->SCREEN_WIDTH * 0.5f, Graphics::Instance()->SCREEN_HEIGHT * 0.5f));

	mLevelNumber = new ScoreBoard({ 75,75,200 });
	mLevelNumber->SetScore(level);
	mLevelNumber->Parent(this);
	mLevelNumber->Pos(Vector2(Graphics::Instance()->SCREEN_WIDTH * 0.65f, Graphics::Instance()->SCREEN_HEIGHT * 0.5f));

	mRoundLabel = new Texture("Round  ", "Q-Bert Original.ttf", 24, { 230,230,230 });
	mRoundLabel->Parent(this);
	mRoundLabel->Pos(Vector2(Graphics::Instance()->SCREEN_WIDTH * 0.5f, Graphics::Instance()->SCREEN_HEIGHT * 0.6f));

	mRoundNumber = new ScoreBoard({ 75,75,200 });
	mRoundNumber->SetScore(round);
	mRoundNumber->Parent(this);
	mRoundNumber->Pos(Vector2(Graphics::Instance()->SCREEN_WIDTH * 0.65f, Graphics::Instance()->SCREEN_HEIGHT * 0.6f));

	mLevelOnScreen = 0.0f;
	mLevelOffScreen = 1.5f;

	//Level Entites
	mDisk1 = new Texture("Disk.png");
	mDisk2 = new Texture("Disk.png");


	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < i+1; j++)
		{
			mCube[i][j] = new Cube();
			mCube[i][j]->Parent(this);
			mCube[i][j]->SetMAXBounce(mLevel);
			mCube[i][j]->GetRound(mRound);
		}
	}

	
	//Disk Postioning

	mDisk1->Pos(Vector2(150, 310));
	mDisk2->Pos(Vector2(570, 310));

	//Cubes Positioning

	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < i + 1; j++)
		{
			mCube[i][j]->Pos(Vector2(360 - (i * 30) + (j * 60), 200 +( 52 * i)));
		}
	}
	
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < i + 1; j++)
		{
			Vector2 pos = mCube[i][j]->Pos();
			SDL_Log("Position of Cube %d %d  is  (%lf  , %lf  )", i + 1, j + 1, pos.x, pos.y);
		}
	}

	mPlayer = player;
	mPlayer->Parent(this);

}

Level::~Level()
{
	mTimer = NULL;
	RightSideBar = NULL;


	delete mLevelLabel;
	mLevelLabel = NULL;

	delete mLevelNumber;
	mLevelNumber = NULL;

	delete mRoundLabel;
	mRoundLabel = NULL;

	delete mRoundNumber;
	mRoundNumber = NULL;

	delete mDisk1;
	mDisk1 = NULL;

	delete mDisk2;
	mDisk2 = NULL;

	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < i+1; j++)
		{
			mCube [i][j] = NULL;
		}
	}


	mPlayer = NULL;
}

void Level::Reset(int level , int round)
{
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j <= i; j++)
		{
			mCube[i][j]->SetMAXBounce(level);
			mCube[i][j]->GetRound(round);
		}
	}
}

void Level::Collision(Player * player , Cube * box)
{
	box->Hit();
	if (box->GetBounce() < mRound)
	{
		player->CubeLanded();
	}
}

void Level::StartRound()
{
	mLevelStarted = true;
}

void Level::Update()
{
	if (!mLevelStarted)
	{
		mLabelTimer += mTimer->DeltaTime();
		if (mLabelTimer > mLevelOffScreen)
		{
			StartRound();
			mPlayer->Active(true);
			mPlayer->Visible(true);
		
		}
	}
	Vector2 CurPos = mPlayer->Pos();
	//SDL_Log("Current Position of Player : %f %f ", CurPos.x, CurPos.y);
	
	SDL_Log("Current Lievs of Player : %d ", mPlayer->Lives());
	SDL_Log("Player Position  at cube: %d %d", XPOS, YPOS);
	SDL_Log("Player Score : %d", mPlayer->Score());

	if(mPlayer->Lives() > 0)
	{
		
		if (mPlayer->GetFlagsStatus('Q'))
		{
			XPOS = XPOS - 1;
			YPOS = YPOS - 1;
			if (XPOS < 0)
			{
				mPlayer->WasHit();
				XPOS = 0;
				YPOS = 0;
				mPlayer->Pos(Vector2(360, 170));
			}
			else
			{
				mPlayer->AddScore(25);
			}
		}
		if (mPlayer->GetFlagsStatus('E'))
		{
			XPOS = XPOS - 1;
			if (XPOS < 0)
			{
				mPlayer->WasHit();
				XPOS = 0;
				YPOS = 0;
				mPlayer->Pos(Vector2(360, 170));
			}
			else
			{
				mPlayer->AddScore(25);
			}
		}
		 if (mPlayer->GetFlagsStatus('A'))
		{
			XPOS= XPOS + 1;
			if (XPOS > 6 )
			{
				mPlayer->WasHit();
				XPOS = 0;
				YPOS = 0;
				mPlayer->Pos(Vector2(360, 170));
			}
			else
			{
				mPlayer->AddScore(25);
			}
		}
		if (mPlayer->GetFlagsStatus('D'))
		{
			XPOS = XPOS + 1;
			YPOS = YPOS + 1;
			if (XPOS > 6 || YPOS > 6)
			{
				mPlayer->WasHit();
				XPOS = 0;
				YPOS = 0;
				mPlayer->Pos(Vector2(360, 170));
			}
			else
			{
				mPlayer->AddScore(25);
			}
		}
		Collision(mPlayer, mCube[XPOS][YPOS]);
		
	}
	SDL_Log("Cube %d %d CurBounce : %d",XPOS, YPOS, mCube[XPOS][YPOS]->GetBounce());
}

void Level::Render()
{
	if (!mLevelStarted)
	{
		mLevelLabel->Render();
		mLevelNumber->Render();
		mRoundLabel->Render();
		mRoundNumber->Render();
	}
	else
	{
		RightSideBar->Render();
	
		
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < i+1; j++)
			{
				mCube[i][j]->Render();
			}
			
		}
		mPlayer->Render();
		mDisk1->Render();
		mDisk2->Render();
	}
}