#include"Player.h"

Player::Player()
{
	mTimer = Timer::Instance();
	mInput = InputManager::Instance();
	mAudio = AudioManager::Instance();

	mVisible = false;
	mAnimating = false;
	mState = false;
	mbounce = 0;
	mScore = 0;
	mLives = 3;

	mQbert = new Texture("QBert.png");
	mQbert->Parent(this);
	mQbert->Pos(VEC2_ZERO);

	MoveSpeed = 60.0f;
	

	//mDeathAnimation = new Texture
	mJumpAnimationA = new AnimatedTexture("QBert Animation A.png", 0, 0, 17, 17, 2, 1.0f, AnimatedTexture::horizontal);
	mJumpAnimationA->Parent(this);
	mJumpAnimationA->Pos(VEC2_ZERO);
	mJumpAnimationA->WrapMode(AnimatedTexture::once);
}

Player::~Player()
{
	mTimer = NULL;
	mInput = NULL;

	delete mQbert;
	mQbert = NULL;

	delete mJumpAnimationA;
	mJumpAnimationA = NULL;

}

void Player::CubeLanded()
{
	mbounce++;
}

void Player::WasHit()
{
	mLives--;
}

void Player::HandleMovement()
{
	for (int i = 0; i < 4; i++)
	{
		flags[i] = false;
	}
	if (mInput->KeyPressed(SDL_SCANCODE_Q))
	{
		flags[0] = true;
		Translate(Vector2(-30,-52) * MoveSpeed * mTimer->DeltaTime());
		
	}
	else if (mInput->KeyPressed(SDL_SCANCODE_E))
	{
		flags[1] = true;
		Translate(Vector2(30, -52)* MoveSpeed * mTimer->DeltaTime());
	}
	else if (mInput->KeyPressed(SDL_SCANCODE_A))
	{
		flags[2] = true;
		Translate(Vector2(-30, 52)* MoveSpeed * mTimer->DeltaTime());
		mJumpAnimationA->ResetAnimation();
	}
	else if (mInput->KeyPressed(SDL_SCANCODE_D))
	{
		flags[3] = true;
		Translate(Vector2(30, 52)* MoveSpeed * mTimer->DeltaTime());
	}

}

void Player::Visible(bool visible)
{
	mVisible = visible;
}

bool Player::IsAnimating()
{
	return mAnimating;
}

bool Player::GetFlagsStatus(char ch)
{
	if (ch == 'Q')
	{
		return flags[0];
	}
	else if (ch == 'E')
	{
		return flags[1];
	}
	else if (ch == 'A')
	{
		return flags[2];
	}
	else if(ch == 'D')
	{
		return flags[3];
	}
}


int Player::Bounce()
{
	return mbounce;
}

int Player::Score()
{
	return mScore;
}

int Player::Lives()
{
	return mLives;
}

void Player::AddScore(int change)
{
	mScore += change;
}

void Player::Update()
{
	if (mAnimating)
	{
		mJumpAnimationA->Update();
		mAnimating = mJumpAnimationA->IsAnimating();
	}
	else
	{
		if (Active())
		{
			
			HandleMovement();
		}
	}

}

void Player::Render()
{
	if (mVisible)
	{
		if (mAnimating)
		{
			mJumpAnimationA->Render();
		}
		else
		{
			mQbert->Render();
		}
	}
}