#include "Timer.h"
#include"AudioManager.h"
#include"ScoreBoard.h"

class PlayerSideBar : public GameEntity
{

private:

	Timer * mTimer;
	AudioManager * mAudio;

	GameEntity * Bar;
	Texture * mPlayer;
	Texture * mPlayerOne;
	Texture * mChangeTo;
	Texture * mMiniCube[4];
	Texture * LeftCursor[2];
	Texture * RightCursor[2];
	Texture * CubeColor;
	ScoreBoard * PlayerScore;

	static const int MAX_LIVES = 3;
	GameEntity * mQbert;
	Texture * mQbertTexture[MAX_LIVES];
	int	 TotalLives;
	int mRound;


public:

	PlayerSideBar();
	~PlayerSideBar();

	void SetPlayerScore(int score);

	void SetPlayerLives(int lives);

	void SetMiniCube(int round);

	void Update();

	void Render();
};
