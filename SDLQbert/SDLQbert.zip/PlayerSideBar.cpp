#include"PlayerSideBar.h"

PlayerSideBar::PlayerSideBar()
{

	mTimer = Timer::Instance();
	mAudio = AudioManager::Instance();
	
	Bar = new GameEntity();
	Bar->Parent(this);
	PlayerScore = new ScoreBoard();

	RightCursor[0] = new Texture("Cursor.png");
	RightCursor[1] = new Texture("Cursor.png");
	LeftCursor[0] = new Texture("LeftCursor.png");
	LeftCursor[1] = new Texture("LeftCursor.png");
	mPlayer = new Texture("Player.png");
	mPlayerOne = new Texture("Number 1.png");
	mChangeTo = new Texture("CHANGE TO ", "Q-bert Original.ttf", 20, { 255,0,0 });
	mMiniCube[0] = new Texture("Mini Cube12.png");
	mMiniCube[1] = new Texture("Mini Cube13.png");
	mMiniCube[2] = new Texture("Mini Cube1.png");

	mPlayer->Pos(Vector2(100, 50));
	mPlayerOne->Pos(Vector2(200, 50));
	PlayerScore->Pos(Vector2(100, 80));
	mChangeTo->Pos(Vector2(120, 140));
	RightCursor[0]->Pos(Vector2(60, 160));
	RightCursor[1]->Pos(Vector2(85, 160));
	mMiniCube[mRound]->Pos(Vector2(115, 160));
	LeftCursor[0]->Pos(Vector2(145, 160));
	LeftCursor[1]->Pos(Vector2(170, 160));

	Bar->Pos(Vector2(Graphics::Instance()->SCREEN_WIDTH * 0.1, Graphics::Instance()->SCREEN_HEIGHT));

	mPlayer->Parent(Bar);
	mPlayerOne->Parent(Bar);
	PlayerScore->Parent(Bar);
	mChangeTo->Parent(Bar);
	RightCursor[0]->Parent(Bar);
	RightCursor[1]->Parent(Bar);
	mMiniCube[mRound]->Parent(Bar);
	LeftCursor[0]->Parent(Bar);
	LeftCursor[1]->Parent(Bar);


	mQbert = new GameEntity();
	mQbert->Parent(this);
	mQbert->Pos(Vector2(50 ,270 ));


	for (int i = 0; i < MAX_LIVES; i++)
	{
		mQbertTexture[i] = new Texture("QBert Lives.png");
		mQbertTexture[i]->Parent(mQbert);
		mQbertTexture[i]->Pos(Vector2(32 * (i / 3), 32 * (i % 3)));
	}
}

PlayerSideBar ::~PlayerSideBar()
{
	delete PlayerScore;
	PlayerScore = NULL;

	delete RightCursor[0];
	RightCursor[0] = NULL;

	delete RightCursor[1];
	RightCursor[1] = NULL;

	delete LeftCursor[0];
	LeftCursor[0] = NULL;

	delete LeftCursor[1];
	LeftCursor[1] = NULL;

	delete mPlayer;
	mPlayer = NULL;

	delete mPlayerOne;
	mPlayerOne = NULL;

	delete mChangeTo;
	mChangeTo = NULL;

	delete Bar;
	Bar = NULL;
	
	mTimer = NULL;
	mAudio = NULL;


	delete mQbert;
	mQbert = NULL;

	for (int i = 0; i < MAX_LIVES; i++)
	{
		delete mQbertTexture[i];
		mQbertTexture[i] = NULL;
	}

	for (int i = 0; i < 3; i++)
	{
		delete mMiniCube[i];
		mMiniCube[i] = NULL;
	}
}

void PlayerSideBar::SetPlayerLives(int lives)
{
	TotalLives = lives;
}

void PlayerSideBar::SetPlayerScore(int score)
{
	PlayerScore->SetScore(score);
}

void PlayerSideBar::Update()
{

}

void PlayerSideBar::SetMiniCube(int round)
{
	mRound = round;
}

void PlayerSideBar::Render()
{
	mPlayer->Render();
	mPlayerOne->Render();
	PlayerScore->Render();
	mChangeTo->Render();
	RightCursor[0]->Render();
	RightCursor[1]->Render();

	LeftCursor[0]->Render();
	LeftCursor[1]->Render();
	mMiniCube[mRound]->Render();
	for (int i = 0; i < TotalLives && i<MAX_LIVES ; i++)
	{
		mQbertTexture[i]->Render();
	}

}